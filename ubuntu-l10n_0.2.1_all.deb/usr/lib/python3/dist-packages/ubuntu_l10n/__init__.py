"""Ubuntu/Launchpad translation statistics viewer."""
